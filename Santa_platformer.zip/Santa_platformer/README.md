# Platformer-Espriu_Bach
Game development platformer
Som un grup de dos estudiants del citm fent un platformer:

Controls:
w:salt
a:dreta
d:esquerra
espai: lliscar
